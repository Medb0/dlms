function change() {
    var img = document.getElementById('seat');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change2() {
    var img = document.getElementById('seat2');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change3() {
    var img = document.getElementById('seat3');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change4() {
    var img = document.getElementById('seat4');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change5() {
    var img = document.getElementById('seat5');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change6() {
    var img = document.getElementById('seat6');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change7() {
    var img = document.getElementById('seat7');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change8() {
    var img = document.getElementById('seat8');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change9() {
    var img = document.getElementById('seat9');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change10() {
    var img = document.getElementById('seat10');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change11() {
    var img = document.getElementById('seat11');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change12() {
    var img = document.getElementById('seat12');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change13() {
    var img = document.getElementById('seat13');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change14() {
    var img = document.getElementById('seat14');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change15() {
    var img = document.getElementById('seat15');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change16() {
    var img = document.getElementById('seat16');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change17() {
    var img = document.getElementById('seat17');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change18() {
    var img = document.getElementById('seat18');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change19() {
    var img = document.getElementById('seat19');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change20() {
    var img = document.getElementById('seat20');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change21() {
    var img = document.getElementById('seat21');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change22() {
    var img = document.getElementById('seat22');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change23() {
    var img = document.getElementById('seat23');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change24() {
    var img = document.getElementById('seat24');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change25() {
    var img = document.getElementById('seat25');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}

function change26() {
    var img = document.getElementById('seat26');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change27() {
    var img = document.getElementById('seat27');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change28() {
    var img = document.getElementById('seat28');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change29() {
    var img = document.getElementById('seat29');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change30() {
    var img = document.getElementById('seat30');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change31() {
    var img = document.getElementById('seat31');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change32() {
    var img = document.getElementById('seat32');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change33() {
    var img = document.getElementById('seat33');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change34() {
    var img = document.getElementById('seat34');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change35() {
    var img = document.getElementById('seat35');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change36() {
    var img = document.getElementById('seat36');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change37() {
    var img = document.getElementById('seat37');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change38() {
    var img = document.getElementById('seat38');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change39() {
    var img = document.getElementById('seat39');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change40() {
    var img = document.getElementById('seat40');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change41() {
    var img = document.getElementById('seat41');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change42() {
    var img = document.getElementById('seat42');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change43() {
    var img = document.getElementById('seat43');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change44() {
    var img = document.getElementById('seat44');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change45() {
    var img = document.getElementById('seat45');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change46() {
    var img = document.getElementById('seat46');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change47() {
    var img = document.getElementById('seat47');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change48() {
    var img = document.getElementById('seat48');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change49() {
    var img = document.getElementById('seat49');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change50() {
    var img = document.getElementById('seat50');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change51() {
    var img = document.getElementById('seat51');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change52() {
    var img = document.getElementById('seat52');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change53() {
    var img = document.getElementById('seat53');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change54() {
    var img = document.getElementById('seat54');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change55() {
    var img = document.getElementById('seat55');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change56() {
    var img = document.getElementById('seat56');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change57() {
    var img = document.getElementById('seat57');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change58() {
    var img = document.getElementById('seat58');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change59() {
    var img = document.getElementById('seat59');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change60() {
    var img = document.getElementById('seat60');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change61() {
    var img = document.getElementById('seat61');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change62() {
    var img = document.getElementById('seat62');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change63() {
    var img = document.getElementById('seat63');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change64() {
    var img = document.getElementById('seat64');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change65() {
    var img = document.getElementById('seat65');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change66() {
    var img = document.getElementById('seat66');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change67() {
    var img = document.getElementById('seat67');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change68() {
    var img = document.getElementById('seat68');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change69() {
    var img = document.getElementById('seat69');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change70() {
    var img = document.getElementById('seat70');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change71() {
    var img = document.getElementById('seat71');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change72() {
    var img = document.getElementById('seat72');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change73() {
    var img = document.getElementById('seat73');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change74() {
    var img = document.getElementById('seat74');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change75() {
    var img = document.getElementById('seat75');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}

function change76() {
    var img = document.getElementById('seat76');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change77() {
    var img = document.getElementById('seat77');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change78() {
    var img = document.getElementById('seat78');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change79() {
    var img = document.getElementById('seat79');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change80() {
    var img = document.getElementById('seat80');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change81() {
    var img = document.getElementById('seat81');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change82() {
    var img = document.getElementById('seat82');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change83() {
    var img = document.getElementById('seat83');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change84() {
    var img = document.getElementById('seat84');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change85() {
    var img = document.getElementById('seat85');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change86() {
    var img = document.getElementById('seat86');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change87() {
    var img = document.getElementById('seat87');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change88() {
    var img = document.getElementById('seat88');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change89() {
    var img = document.getElementById('seat89');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change90() {
    var img = document.getElementById('seat90');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change91() {
    var img = document.getElementById('seat91');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change92() {
    var img = document.getElementById('seat92');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change93() {
    var img = document.getElementById('seat93');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change94() {
    var img = document.getElementById('seat94');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change95() {
    var img = document.getElementById('seat95');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change96() {
    var img = document.getElementById('seat96');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change97() {
    var img = document.getElementById('seat97');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change98() {
    var img = document.getElementById('seat98');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}
function change99() {
    var img = document.getElementById('seat99');
    
    if(img.src.match('mcloset')){
        img.src = "./images/locker-room.png"
    }else {
        img.src = "./images/mcloset.png"
    }
}




















