function openSlideMenu() {
    document.getElementById('menu').style.width='300px';
    document.getElementById('wrapper').style.marginLeft='300px';
}
function closeSlideMenu() {
    document.getElementById('menu').style.width='0';
    document.getElementById('wrapper').style.marginLeft='0';
}